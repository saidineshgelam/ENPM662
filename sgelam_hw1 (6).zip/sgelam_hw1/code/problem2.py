import numpy as np #imports numpy to solve trignometric funtions
import matplotlib.pyplot as plt #imports matplots to plot trajectory

# Initial boundary conditions
x = 0.0  # Initial x-coordinate is considered as 0
y = 0.0  # Initial y-coordinate is considered as 0
phi = 0.0  # Initial orientation angle (in radians) is considered as 0
omega = 3.0  # Assume Rear wheel drive angular speed (rad/s) as 3rad/sec
T = 5.0  # Total duration of trjectory is 5(seconds)
# Constants
wheelradius = 0.25  # Radius of the rear wheel (0.5 m diameter)
wheel_to_wheel_distance = 1.5  # Distance between the wheels (1.5 m)

# Time step for simulation
dt = 0.01# small time interval needed for the computation of x y teta values
# Initialize arrays to store trajectory points
x_tr = [x] 
y_tr = [y]

# Simulate the bicycle's motion and compute the trajectory
for t in np.arange(0, T, dt): # this loop runs from T=0, incrementing dt untill T= 5 sec 
    alpha = 0.5 * np.sin(np.pi * t)  # Steering angle (input)

    # Update the state using the state-space model
    V = omega * wheelradius 
    x_dot = V * np.cos(phi - alpha ) 
    y_dot = V * np.sin(phi - alpha)
    theta_dot = (V / wheel_to_wheel_distance) * np.tan(alpha)

    x += dt * x_dot
    y += dt * y_dot
    phi += dt * theta_dot

    # Append the new position to the trajectory
    x_tr.append(x)
    y_tr.append(y)  #for ends here

# Plot the trajectory
plt.figure(figsize=(8, 6))
plt.plot(x_tr, y_tr, label='bicycle Trajectory')
plt.xlabel('X-coordinate (m)')
plt.ylabel('Y-coordinate (m)')
plt.title('2D Trajectory of Bicycle')
plt.legend()
plt.grid(True)
plt.show()
