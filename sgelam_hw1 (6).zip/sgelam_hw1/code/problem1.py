from sympy import init_printing # imports sympy libraries to compute matrix operations
init_printing(use_unicode=True)
from sympy import *
from sympy.matrices import Matrix
l1, l2, l3, te1, te2, te3, xdot, ydot, tedot = symbols("l1, l2, l3, te1, te2, te3, xdot, ydot, tedot ") #variables used 
x = l1*cos(te1) + l2*cos(te1-te2) + l3*cos(te3-te1+te2)# x co-ordinate of end effector after geometrical approach
y = l1*sin(te1) + l2*sin(te1-te2) - l3*sin(te3-te1+te2)# y co-ordinate after effector geometrical approach
teta = te1-te2-te3 # final orientstion angle of the end effector
derivative_xte1 = x.diff(te1) #d/dte1(x)
derivative_yte1 = y.diff(te1)#d/dte1(y)
derivative_tete1 = teta.diff(te1)#d/dte1(teta)
# print(derivative_xte1)
# print(derivative_yte1)
# print(derivative_tete1)
derivative_xl1 = x.diff(l1) #d/dl1(x)
derivative_yl1 = y.diff(l1)#d/dl1(y)
derivative_tel1 = teta.diff(l1)#d/dl1(te)
# print(derivative_xl1)
#print(derivative_yl1)
#print(derivative_tel1)
derivative_xte3 = x.diff(te3)#d/dte3(x)
derivative_yte3 = y.diff(te3)#d/dte3(y)
derivative_tete3 = teta.diff(te3)#d/dte3(te)
#print(derivative_xte3)
#print(derivative_yte3)
#print(derivative_tete3)
#arranging the jocobian matrix j
j= Matrix([[derivative_xl1, derivative_xte1, derivative_xte3], 
           [derivative_yl1, derivative_yte1, derivative_yte3], [derivative_tel1, derivative_tete1, derivative_tete3]]) 
#print(pretty(j))
# finding inverse of matrix
inv = j.inv()
#print(pretty(inv))
C = Matrix([[xdot], [ydot],[tedot ]])# required variable matrix
solution = inv * C
solution # print solution matrix
print(pretty(solution))