This file helps you to find the way to solutions of the Modeling Assignment -1 questions 1, and 2(a), 2(b)

there are two .py files code uploaded along with a hand written report( both questions in a single report), screenshots of output.

Follow the following process to asses the assignment questions

Before executing the codes in  Vscode make sure your system have the following
python3.
Numpy
sympy

or else please enter the following comands in the workspace terminal
>> sudo apt-get install python3-sympy
>>python3 -m pip install numpy


Question 1
There is no requirement of entering and any input for computation, every input is given in code
just open the code and click run, you get the trajectory of point “o”

Question 2
Answers of both 2(a) and 2(b) are combined in a single code and single report, as they are inter depended
There is no requirement of entering and any input for computation, every input is given in code
just open the code and click run, you get final answer of inverse kinematics matrix giving the values of 
( L1, TE1, TE3 ). You can also uncomment the lines to see the Jacobian and Inverse Jacobian matrix.
