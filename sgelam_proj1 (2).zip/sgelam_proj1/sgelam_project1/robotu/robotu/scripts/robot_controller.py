#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from std_msgs.msg import Float64MultiArray
from geometry_msgs.msg import Quaternion
import numpy as np
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import math
from rclpy.time import Time
from geometry_msgs.msg import Vector3
import matplotlib.pyplot as plt


class RobotControl(Node):
    def __init__(self):
        super().__init__('robot_controller')

        self.joint_position_pub = self.create_publisher(
            Float64MultiArray, '/position_controller/commands', 10)
        self.wheel_velocities_pub = self.create_publisher(
            Float64MultiArray, '/velocity_controller/commands', 10)

        self.qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        self.subscription = self.create_subscription(
            Imu,
            '/imu_plugin/out',
            self.imu_callback,
            self.qos_profile)
        self.subscription
        self.time_step = 0.1  # seconds
        self.timer = self.create_timer(self.time_step, self.timer_callback)
        self.i = 0.01
        self.joint_pos = Float64MultiArray()
        self.wheel_vel = Float64MultiArray()
        self.present_quat = Quaternion
        self.initial_position = [0.0, 0.0]
        self.target_position = [10.0, 10.0]
        self.distance = math.sqrt(((self.target_position[1]-self.initial_position[1])**2+(
            self.target_position[0]-self.initial_position[0])**2))
        self.current_yaw = 0.0
        self.target_yaw = math.atan((self.target_position[1]-self.initial_position[1])/(
            self.target_position[0]-self.initial_position[0]))
        self.clock = Node.get_clock(self)
        self.previous_time = self.clock.now()

        self.linear_acceleration = Vector3()
        self.ang_velocity = Vector3()

        self.x_position = 0.0
        self.y_position = 0.0

        self.total_time = 15.0
        self.target_velocity = self.distance/self.total_time  
        self.kp = 10.0
        self.kp_pos = -18.5

        self.target_x = 0.0
        self.target_y = 0.0

        self.x_velocity = 0.0
        self.y_velocity = 0.0
        self.current_vel = 0.0
        self.my_pos = 0.0
        self.my_posy = 0.0
        self.error_list_yaw = []
        self.control_list = []
        self.error_list_vel = []
        self.time_list = []

    def timer_callback(self):
        self.present_time = self.clock.now()
        dt = (self.present_time - self.previous_time).nanoseconds / 1e9
        self.x_velocity += self.linear_acceleration.x*dt
        self.y_velocity += self.linear_acceleration.y*dt

        if self.i < self.total_time:
            velocity_error = (self.target_velocity - (self.x_velocity))
            self.current_vel = self.kp_pos*velocity_error
        else:
            self.current_vel = 0.0
            self.plot()
            
        yaw_error = self.target_yaw - self.current_yaw
        steer_angle = self.kp*yaw_error
        print(yaw_error, steer_angle)
        if steer_angle < -0.2:
            steer_angle = -0.2
        if steer_angle > 0.2:
            steer_angle = 0.2

        self.wheel_vel.data = [
            self.current_vel, -self.current_vel, -self.current_vel, self.current_vel]
        self.joint_pos.data = [steer_angle, steer_angle]
        self.joint_position_pub.publish(self.joint_pos)
        self.wheel_velocities_pub.publish(self.wheel_vel)
        self.previous_time = self.present_time
        self.i = self.i+self.time_step
        self.error_list_yaw.append(yaw_error)
        self.error_list_vel.append(velocity_error)
        self.time_list.append(self.i)
        self.control_list.append(self.current_vel)
# plot graphs

    def plot(self):
        plt.figure(figsize=(12, 6))  # Adjust the figure size if needed

        # Plot Yaw Error
        plt.subplot(2, 1, 1)  # Create a subplot for error
        plt.plot(self.time_list, self.error_list_yaw,
                 label='Yaw Error', color='red')
        plt.plot(self.time_list, self.error_list_vel,
                 label='Velocity Error', color='green')
        plt.xlabel('Time')
        plt.ylabel('Error')
        plt.title('Error vs Time')
        plt.legend()

        # Plot Velocity
        plt.subplot(2, 1, 2)  # Create a subplot for velocity
        plt.plot(self.time_list, self.control_list,
                 label='Velocity', color='orange')
        plt.xlabel('Time')
        plt.ylabel('Velocity')
        plt.title('Velocity vs Time')
        plt.legend()

        plt.tight_layout()  # To ensure proper spacing between subplots
        plt.show()

    def imu_callback(self, msg):
        self.present_quat = msg.orientation
        self.ang_velocity = msg.angular_velocity
        numerator = 2 * \
            (self.present_quat.w*self.present_quat.z +
             self.present_quat.z*self.present_quat.y)
        denominator = 1 - \
            (2*(np.square(self.present_quat.y) +
             np.square(self.present_quat.z)))
        self.current_yaw = math.atan2(numerator, denominator)
        self.linear_acceleration = msg.linear_acceleration


def main(args=None):
    rclpy.init(args=args)
    robot_controller = RobotControl()
    rclpy.spin(robot_controller)
    robot_controller.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
