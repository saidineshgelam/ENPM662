ENPM 662: Project 1

Project title: CAD Modelling & Simulation using Gazebo

Package - robotu
This ROS 2 package is part of the ENPM 662 Modeling project and serves as the control and simulation environment for a robot car.



#Package Contents
-Launch Files: The package includes launch files for running the Gazebo simulation, RViz visualization, and other components of the robot.

-CMakeLists.txt: The CMake configuration for building the ROS 2 package.

-URDF (Unified Robot Description Format): The URDF file provides a detailed description of the robot's structure, including links, joints, and visual properties.

-Meshes: This directory contains 3D mesh files for the robot's visual representation in the simulation environment.

-package.xml: The package manifest file that defines package dependencies and other metadata.

-Competition Setup: Configuration files and launch files for setting up the robot for competition scenarios.

-Source Code: The package's scripts directory contains three Python files:
	-teleop.py: Teleoperation code for manual control of the robot.
	-robot_controller.py: Code for implementing a proportional controller to guide the robot from one point to another.

#Dependencies:
-ROS Controller package and controller manager
```bash
sudo apt install ros-galactic-ros2-control ros-galactic-ros2-controllers ros-galactic-gazebo-ros2-control
sudo apt-get install ros-galactic-controller-manager





#Steps to execute the project:
-Create a ROS2 workspace.

- Add the package: Unzip the project files and place them under the src folder in your ROS 2 workspace.

- Build and Source: Source your bashrc and ROS 2 distribution, build the package, and source your workspace:
```bash
source /opt/ros/galactic/setup.bash
colcon build
source /path/to/your/workspace/install/setup.bash

-Spawn the Model in Empty World for Teleop: Launch the Gazebo simulation for teleoperation:
source /path/to/your/workspace/install/setup.bash
ros2 launch toy_car gazebo.launch.py

Open a second terminal and run the teleoperation node:
source /path/to/your/workspace/install/setup.bash
ros2 run robotu teleop.py

-Spawn the Model in Competition World for Teleop: Launch the Gazebo simulation in the competition world:
source /path/to/your/workspace/install/setup.bash
ros2 launch robotu competition.launch.py

Open a second terminal and run the teleoperation node:
source /path/to/your/workspace/install/setup.bash
ros2 run robotu teleop.py

-Run the Proportional Controller: Ensure that the position and orientation values in spawn_robot_ros2.launch.py are set to 0.
Launch Gazebo simulation:
source /path/to/your/workspace/install/setup

Run the proportional controller in a separate terminal:
ros2 run robotu robot_controller.py




#Note:
The zip folders submitted by either one of us has the same contents.




#Maintainers

-Raghu Dharahas Reddy Kotla (raghu17@umd.edu)
-Sai Dinesh Gelam (sgelam@umd.edu)
